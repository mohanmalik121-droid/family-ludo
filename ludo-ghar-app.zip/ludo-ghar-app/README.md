# Ludo Ghar: app banane ki guide

Is folder mein game ke saath dono raaste ready hain:

- **PWA**: link se khulta hai, phone ki home screen par app jaisa install hota hai.
- **Android APK**: Capacitor se asli Android app, Play Store ke liye bhi.

```
ludo-ghar-app/
  www/                  <- poora game yahin hai
    index.html
    manifest.webmanifest
    sw.js               <- offline support
    icons/
  package.json          <- APK ke liye
  capacitor.config.json
```

---

## Raasta 1: PWA (sabse aasaan, 10 minute)

PWA ko internet par ek https link chahiye. Free options:

### Netlify Drop (sabse tez, koi account ka jhanjhat nahi)
1. https://app.netlify.com/drop kholo.
2. Sirf `www` folder ko page par drag and drop karo.
3. Netlify ek link dega, jaise `https://kuch-naam.netlify.app`.

### GitHub Pages
1. GitHub par naya repository banao.
2. `www` ke andar ki saari files repository mein upload karo (`index.html` repository ke root mein honi chahiye).
3. Repository Settings > Pages mein branch `main` chuno aur Save karo.
4. Kuch der baad link `https://aapka-naam.github.io/repo-naam/` par milega.

### Phone par install karna
- **Android (Chrome):** link kholo, menu (3 dots) > **Install app** ya **Add to Home screen**.
- **iPhone (Safari):** link kholo, Share button > **Add to Home Screen**.

Pehli baar internet se kholo. Uske baad game offline bhi chalta hai.

### Dost ko bhejna
Bas wahi link WhatsApp par bhej do. Wo bhi isi tarah install kar sakta hai.

---

## Raasta 2: Android APK

### Zaroori cheezein (apne computer par, ek baar)
1. **Node.js** (LTS version): https://nodejs.org
2. **Android Studio**: https://developer.android.com/studio (install ke baad ek baar khol kar SDK download hone do)
3. **Java 17** Android Studio ke saath aa jata hai, alag se kuch nahi chahiye.

### Steps
Terminal ya Command Prompt mein is folder ke andar jao (`ludo-ghar-app`) aur ye chalao:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio khulega. Phir:

1. Gradle sync poora hone ka wait karo (neeche progress bar dikhta hai).
2. Menu mein **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Kaam hone par neeche "locate" ka link aata hai. APK is path par milti hai:
   `android/app/build/outputs/apk/debug/app-debug.apk`
4. Ye file phone mein bhej do (WhatsApp, USB ya Drive) aur install karo. Phone mein "Install unknown apps" allow karna pad sakta hai.

### Game mein badlav karne ke baad
`www/index.html` badlo, phir:

```bash
npx cap sync android
```

aur Android Studio se dobara APK banao.

### App ka icon (optional)
Abhi Android ka default icon lagega. Apna icon lagane ke liye `www/icons/icon-512.png` ko dekho, aur Android Studio mein `android/app/src/main/res` par right-click > **New > Image Asset** se is image ko chuno.

---

## Play Store par dalna

1. Google Play Developer account chahiye (ek baar ka $25 fee).
2. Debug APK nahi chalega. Android Studio mein **Build > Generate Signed Bundle / APK** se signed `.aab` banao.
3. `capacitor.config.json` mein `appId` ko apne naam se badlo (jaise `com.aapkanaam.ludoghar`). Ye baad mein badalna mushkil hota hai.
4. App ki description, screenshots aur privacy policy Play Console mein daalo.

Is game mein paisa, jua ya account nahi hai. Play Store par ye "real money gaming" ki category mein nahi aata, aur aage bhi aisa kuch jodna ho toh pehle Play Store ke gambling rules padh lena.

---

## Game ke baare mein

- Ek device par 2 se 4 players, ya computer (bot) ke saath.
- 6 aane par token niklega aur dobara baari milegi. Token kaatne par ya ghar pahunchne par bhi dobara baari.
- Star aur rang wale start square safe hain.
- Teen 6 lagatar aane par baari chali jati hai.
- Ghar tak pahunchne ke liye ginti poori seedhi chahiye.

Code poora `www/index.html` ek hi file mein hai. Online multiplayer abhi nahi hai.
